import css.ApplicationButton;

import javax.swing.*;

public class MainMenu extends JPanel {

    private MainFrame parent;

    private ApplicationButton firstPageButton;
    private ApplicationButton secondPageButton;
    private ApplicationButton exitButton;

    public MainMenu(MainFrame parent){

        this.parent = parent;

        setSize(500,500);
        setLayout(null);

        firstPageButton = new ApplicationButton("ADD PLAYER");
        firstPageButton.setSize(300,30);
        firstPageButton.setLocation(100,100);
        add(firstPageButton);
        firstPageButton.addActionListener(e -> {
            parent.getMainMenu().setVisible(false);
            parent.getAddUserPage().setVisible(true);
        });

        secondPageButton = new ApplicationButton("LIST PLAYERS");
        secondPageButton.setSize(300,30);
        secondPageButton.setLocation(100,150);
        add(secondPageButton);
        secondPageButton.addActionListener(e -> {
            parent.getListUsersPage().generateTable(parent.getPlayers());
            parent.getMainMenu().setVisible(false);
            parent.getListUsersPage().setVisible(true);
        });

        exitButton = new ApplicationButton("EXIT");
        exitButton.setSize(300,30);
        exitButton.setLocation(100,200);
        add(exitButton);
        exitButton.addActionListener(e -> {

            System.exit(0);

        });

    }

}
